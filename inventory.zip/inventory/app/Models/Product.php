<?php
/**
 * Created by PhpStorm.
 * User: Shovo
 * Date: 25-Mar-20
 * Time: 8:17 PM
 */

namespace App\Models;


use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    protected $connection = 'mysql';
    protected $table = 'product';
    public $timestamps = false;
    protected $primaryKey = "product_id";

}
