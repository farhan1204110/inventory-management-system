<?php

namespace App\Admin\Controllers;

use App\Models\Purchase;
use Encore\Admin\Controllers\AdminController;
use Encore\Admin\Form;
use Encore\Admin\Grid;
use Encore\Admin\Show;

class PurchaseController extends AdminController
{
    /**
     * Title for current resource.
     *
     * @var string
     */
    protected $title = 'Purchase';

    /**
     * Make a grid builder.
     *
     * @return Grid
     */
    protected function grid()
    {
        $grid = new Grid(new Purchase());

        $grid->column('Product_ID', __('Product ID'));
        $grid->column('Product_Name', __('Product Name'));
        $grid->column('Line', __('Line'));
        $grid->column('Machine', __('Machine'));
        $grid->column('Date_Purchased', __('Date Purchased'));
        $grid->column('Quantity', __('Quantity'));
        $grid->column('Unit_Price', __('Unit Price'));
        $grid->column('Total_Price', __('Total Price'));
        $grid->column('Cost_Center', __('Cost Center'));
        $grid->column('Rack', __('Rack'));
        $grid->column('Purchase_Order', __('Purchase Order'));

        return $grid;
    }

    /**
     * Make a show builder.
     *
     * @param mixed $id
     * @return Show
     */
    protected function detail($id)
    {
        $show = new Show(Purchase::findOrFail($id));

        $show->field('Product_ID', __('Product ID'));
        $show->field('Product_Name', __('Product Name'));
        $show->field('Line', __('Line'));
        $show->field('Machine', __('Machine'));
        $show->field('Date_Purchased', __('Date Purchased'));
        $show->field('Quantity', __('Quantity'));
        $show->field('Unit_Price', __('Unit Price'));
        $show->field('Total_Price', __('Total Price'));
        $show->field('Cost_Center', __('Cost Center'));
        $show->field('Rack', __('Rack'));
        $show->field('Purchase_Order', __('Purchase Order'));

        return $show;
    }

    /**
     * Make a form builder.
     *
     * @return Form
     */
    protected function form()
    {
        $form = new Form(new Purchase());

        $form->number('Product_ID', __('Product ID'));
        $form->text('Product_Name', __('Product Name'));
        $form->text('Line', __('Line'));
        $form->text('Machine', __('Machine'));
        $form->date('Date_Purchased', __('Date Purchased'))->default(date('Y-m-d'));
        $form->number('Quantity', __('Quantity'));
        $form->number('Unit_Price', __('Unit Price'));
        $form->number('Total_Price', __('Total Price'));
        $form->number('Cost_Center', __('Cost Center'));
        $form->text('Rack', __('Rack'));

        return $form;
    }
}
