<?php

namespace App\Admin\Controllers;

use App\Models\Issue;
use Encore\Admin\Controllers\AdminController;
use Encore\Admin\Form;
use Encore\Admin\Grid;
use Encore\Admin\Show;

class IssueController extends AdminController
{
    /**
     * Title for current resource.
     *
     * @var string
     */
    protected $title = 'Issue';

    /**
     * Make a grid builder.
     *
     * @return Grid
     */
    protected function grid()
    {
        $grid = new Grid(new Issue());

        $grid->column('product_id', __('Product id'));
        $grid->column('product_name', __('Product name'));
        $grid->column('issue_date', __('Issue date'));
        $grid->column('quantity', __('Quantity'));
        $grid->column('cost_centre', __('Cost centre'));
        $grid->column('received_by', __('Received by'));
        $grid->column('authorized_by', __('Authorized by'));

        return $grid;
    }

    /**
     * Make a show builder.
     *
     * @param mixed $id
     * @return Show
     */
    protected function detail($id)
    {
        $show = new Show(Issue::findOrFail($id));

        $show->field('product_id', __('Product id'));
        $show->field('product_name', __('Product name'));
        $show->field('issue_date', __('Issue date'));
        $show->field('quantity', __('Quantity'));
        $show->field('cost_centre', __('Cost centre'));
        $show->field('received_by', __('Received by'));
        $show->field('authorized_by', __('Authorized by'));

        return $show;
    }

    /**
     * Make a form builder.
     *
     * @return Form
     */
    protected function form()
    {
        $form = new Form(new Issue());

        $form->text('product_name', __('Product name'));
        $form->date('issue_date', __('Issue date'))->default(date('Y-m-d'));
        $form->number('quantity', __('Quantity'));
        $form->number('cost_centre', __('Cost centre'));
        $form->text('received_by', __('Received by'));
        $form->text('authorized_by', __('Authorized by'));

        return $form;
    }
}
