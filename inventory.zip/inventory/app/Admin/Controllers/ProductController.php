<?php

namespace App\Admin\Controllers;

use App\Models\Product;
use Encore\Admin\Controllers\AdminController;
use Encore\Admin\Form;
use Encore\Admin\Grid;
use Encore\Admin\Show;

class ProductController extends AdminController
{
    /**
     * Title for current resource.
     *
     * @var string
     */
    protected $title = 'Product';

    /**
     * Make a grid builder.
     *
     * @return Grid
     */
    protected function grid()
    {
        $grid = new Grid(new Product());

        $grid->column('product_id', __('Id'));
        $grid->column('product_name', __('Product name'));
        $grid->column('line', __('Line'));
        $grid->column('machine', __('Machine'));
        $grid->column('cost_center', __('Cost center'));
        $grid->column('stock', __('Stock'));
        $grid->column('re_order_point', __('Re order point'));
        $grid->column('rack_no', __('Rack no'));
        $grid->column('received_quantity', __('Received quantity'));
        $grid->column('consumption', __('Consumption'));
        $grid->column('status', __('Status'));
        $grid->column('details', __('Details'));
        $grid->column('created_at', __('Created at'));
        $grid->column('updated_at', __('Updated at'));
        $grid->column('created_by', __('Created by'));

        return $grid;
    }

    /**
     * Make a show builder.
     *
     * @param mixed $id
     * @return Show
     */
    protected function detail($id)
    {
        $show = new Show(Product::findOrFail($id));

        $show->field('product_id', __('Product id'));
        $show->field('product_name', __('Product name'));
        $show->field('line', __('Line'));
        $show->field('machine', __('Machine'));
        $show->field('cost_center', __('Cost center'));
        $show->field('stock', __('Stock'));
        $show->field('re_order_point', __('Re order point'));
        $show->field('rack_no', __('Rack no'));
        $show->field('received_quantity', __('Received quantity'));
        $show->field('consumption', __('Consumption'));
        $show->field('status', __('Status'));
        $show->field('details', __('Details'));
        $show->field('created_at', __('Created at'));
        $show->field('updated_at', __('Updated at'));
        $show->field('created_by', __('Created by'));

        return $show;
    }

    /**
     * Make a form builder.
     *
     * @return Form
     */
    protected function form()
    {
        $form = new Form(new Product());

        $form->text('product_name', __('Product name'));
        $form->text('line', __('Line'));
        $form->text('machine', __('Machine'));
        $form->decimal('cost_center', __('Cost center'));
        $form->decimal('stock', __('Stock'));
        $form->decimal('re_order_point', __('Re order point'));
        $form->text('rack_no', __('Rack no'));
        $form->decimal('received_quantity', __('Received quantity'));
        $form->decimal('consumption', __('Consumption'));
        $form->number('status', __('Status'));
        $form->text('details', __('Details'));
        $form->text('created_by', __('Created by'));

        return $form;
    }
}
